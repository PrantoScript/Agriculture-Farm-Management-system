<?php
session_start();

// Farmer only access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'farmer') {
    header("Location: index.php");
    exit();
}

// DB connection
$conn = new mysqli("localhost", "root", "", "agfms");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$farmer_id = $_SESSION['user_id'];

/* =========================
   ADD FARM DATA
========================= */
if (isset($_POST['add_farm_data'])) {

    $farm_name = $_POST['farm_name'];
    $location = $_POST['location'];
    $irrigation_schedule = $_POST['irrigation_schedule'];
    $farming_details = $_POST['farming_details'];

    $stmt = $conn->prepare("
        INSERT INTO farm_management 
        (farmer_id, farm_name, location, irrigation_schedule, farming_details)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "issss",
        $farmer_id,
        $farm_name,
        $location,
        $irrigation_schedule,
        $farming_details
    );

    $stmt->execute();
    $stmt->close();

    echo "Farm data added successfully!";
}


/* =========================
   ADD PRODUCT
========================= */
if (isset($_POST['add_product'])) {

    $product_name = $_POST['product_name'];
    $product_description = $_POST['product_description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // image upload
    $product_image = $_FILES['product_image']['name'];
    $tmp = $_FILES['product_image']['tmp_name'];

    $upload_dir = "uploads/";

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $path = $upload_dir . basename($product_image);

    if (move_uploaded_file($tmp, $path)) {

        // IMPORTANT: column names must match DB exactly
        $stmt = $conn->prepare("
            INSERT INTO marketplace 
            (farmer_id, product_name, product_description, price, stock, product_image)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "issdis",
            $farmer_id,
            $product_name,
            $product_description,
            $price,
            $stock,
            $product_image
        );

        $stmt->execute();
        $stmt->close();

        echo "Product added successfully!";
    } else {
        echo "Image upload failed!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Farm</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

<h2>farming</h2>

<h3>Add Farm Data</h3>
<form method="post">
    <input type="text" name="farm_name" placeholder="Farm Name" required>
    <input type="text" name="location" placeholder="Location" required>
    <textarea name="irrigation_schedule" placeholder="Irrigation Schedule"></textarea>
    <textarea name="farming_details" placeholder="Farming Details"></textarea>
    <button type="submit" name="add_farm_data">Add Farm</button>
</form>

<hr>

<h3>Add Product</h3>
<form method="post" enctype="multipart/form-data">
    <input type="text" name="product_name" placeholder="Product Name" required>
    <textarea name="product_description1" placeholder="Description"></textarea>
    <textarea name="product_description" placeholder="Description"></textarea>
    <input type="number" name="price" placeholder="Price" required>
    <input type="number" name="stock" placeholder="Stock" required>
    <input type="file" name="product_image" required>
    <button type="submit" name="add_product">Add Product</button>
    
</form>

<hr>

<h3>Your Farm Data</h3>

<?php
$stmt = $conn->prepare("
    SELECT farm_name, location, irrigation_schedule, farming_details
    FROM farm_management
    WHERE farmer_id = ?
");

$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

    echo "<table border='1'>
            <tr>
                <th>Farm Name</th>
                <th>Location</th>
                <th>Irrigation</th>
                <th>Details</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".htmlspecialchars($row['farm_name'])."</td>
                <td>".htmlspecialchars($row['location'])."</td>
                <td>".htmlspecialchars($row['irrigation_schedule'])."</td>
                <td>".htmlspecialchars($row['farming_details'])."</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "No farm data found.";
}
?>

</body>
</html>
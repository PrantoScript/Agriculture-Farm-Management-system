<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// ✅ Correct DB Connection
$conn = new mysqli("localhost", "root", "", "agfms");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// ================= ADD TO CART =================
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = 1;

    // ✅ Prepared Statement (secure)
    $stmt = $conn->prepare("INSERT INTO cart (buyer_id, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $product_id, $quantity);

    if ($stmt->execute()) {
        echo "Product added to cart!";
    } else {
        echo "Error: " . $stmt->error;
    }
}

// ================= FETCH PRODUCTS =================
$result = $conn->query("SELECT * FROM marketplace");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Marketplace</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

<h2>Marketplace</h2>

<div class="product-list">

<?php
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
?>
        <div class="product-item">
            <img src="uploads/<?php echo htmlspecialchars($row['product_image']); ?>" width="150">

            <h3><?php echo htmlspecialchars($row['product_name']); ?></h3>

            <p>Price: ৳<?php echo $row['price']; ?></p>
            <p>Stock: <?php echo $row['stock']; ?></p>

            <form method="post">
                <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                <button name="add_to_cart">Add to Cart</button>
            </form>
        </div>
<?php
    }
} else {
    echo "No products available.";
}
?>

</div>

</body>
</html>
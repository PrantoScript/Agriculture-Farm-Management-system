<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// ✅ FIXED DB CONNECTION
$conn = new mysqli("localhost", "root", "", "agfms");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// ================= ORDER =================
if (isset($_POST['confirm_order'])) {

    $delivery_address = $_POST['delivery_address'];
    $phone_number = $_POST['phone_number'];

    if (!preg_match("/^[0-9]{11}$/", $phone_number)) {
        echo "<p style='color:red;'>Invalid phone number</p>";
    } else {

        foreach ($_POST['product_ids'] as $product_id) {
            $quantity = $_POST['quantity'][$product_id];

            // ✅ Prepared
            $stmt = $conn->prepare("INSERT INTO orders 
                (buyer_id, product_id, quantity, delivery_address, phone_number) 
                VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiiss", $user_id, $product_id, $quantity, $delivery_address, $phone_number);
            $stmt->execute();

            // Remove from cart
            $del = $conn->prepare("DELETE FROM cart WHERE buyer_id=? AND product_id=?");
            $del->bind_param("ii", $user_id, $product_id);
            $del->execute();
        }

        echo "<p style='color:green;'>Order placed!</p>";
    }
}

// ================= REVIEW =================
if (isset($_POST['submit_review'])) {
    $product_id = $_POST['product_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    $stmt = $conn->prepare("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $user_id, $product_id, $rating, $comment);

    if ($stmt->execute()) {
        echo "Review submitted!";
    }
}

// ================= CART =================
$stmt = $conn->prepare("
    SELECT c.product_id, c.quantity, m.product_name, m.price, m.product_image
    FROM cart c
    JOIN marketplace m ON c.product_id = m.product_id
    WHERE c.buyer_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
}

// ================= ORDERED =================
$stmt = $conn->prepare("
    SELECT o.product_id, m.product_name
    FROM orders o
    JOIN marketplace m ON o.product_id = m.product_id
    WHERE o.buyer_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$order_result = $stmt->get_result();

$ordered_items = [];
while ($row = $order_result->fetch_assoc()) {
    $ordered_items[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Cart</title>
</head>

<body>

<h2>My Cart</h2>

<!-- CART -->
<form method="post">
<?php
if (count($cart_items) > 0) {
    foreach ($cart_items as $item) {
?>
        <div>
            <img src="uploads/<?php echo $item['product_image']; ?>" width="100">
            <h3><?php echo $item['product_name']; ?></h3>
            <p>৳<?php echo $item['price']; ?></p>

            <input type="number" name="quantity[<?php echo $item['product_id']; ?>]" value="<?php echo $item['quantity']; ?>">
            <input type="hidden" name="product_ids[]" value="<?php echo $item['product_id']; ?>">
        </div>
<?php
    }
?>
    <button type="button" onclick="showForm()">Checkout</button>
<?php
} else {
    echo "Cart empty";
}
?>
</form>

<!-- CHECKOUT -->
<form method="post" id="form" style="display:none;">
    <textarea name="delivery_address" placeholder="Address" required></textarea>
    <input type="text" name="phone_number" placeholder="01XXXXXXXXX" required>

<?php
foreach ($cart_items as $item) {
    echo "<input type='hidden' name='product_ids[]' value='".$item['product_id']."'>";
    echo "<input type='hidden' name='quantity[".$item['product_id']."]' value='".$item['quantity']."'>";
}
?>

    <button name="confirm_order">Confirm</button>
</form>

<hr>

<!-- REVIEW -->
<h3>Review</h3>
<form method="post">
    <select name="product_id" required>
        <option value="">Select</option>
        <?php foreach ($ordered_items as $item) { ?>
            <option value="<?php echo $item['product_id']; ?>">
                <?php echo $item['product_name']; ?>
            </option>
        <?php } ?>
    </select>

    <select name="rating">
        <option>1</option><option>2</option><option>3</option>
        <option>4</option><option>5</option>
    </select>

    <textarea name="comment"></textarea>
    <button name="submit_review">Submit</button>
</form>

<script>
function showForm(){
    document.getElementById("form").style.display="block";
}
</script>

</body>
</html>
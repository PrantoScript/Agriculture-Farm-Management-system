<?php
// Database Connection File (Centralized)

$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "agfms";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
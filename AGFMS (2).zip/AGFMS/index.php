<?php
session_start();

// Database configuration
$host = "localhost";
$db_user = "root";     // XAMPP default username
$db_pass = "";         // XAMPP default password (empty)
$database = "agfms";

// Create connection
$conn = new mysqli("localhost", "root", "", "agfms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ================= REGISTER =================
if (isset($_POST['register'])) {
    $user_name = $_POST['username'];
    $user_pass = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    // Prepared statement (secure)
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $user_name, $user_pass, $role);

    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $stmt->error;
    }
}

// ================= LOGIN =================
if (isset($_POST['login'])) {
    $user_name = $_POST['username'];
    $user_pass = $_POST['password'];

    // Prepared statement
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $user_name);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($user_pass, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];

            header("Location: main.php");
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No user found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Agriculture Farm Management System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome to Agriculture Farm Management System</h1>

    <div class="form-container">

        <!-- Register Form -->
        <div class="form-box">
            <form method="post">
                <h2>Register</h2>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                
                <select name="role" required>
                    <option value="farmer">Farmer</option>
                    <option value="buyer">Buyer</option>
                </select>

                <button type="submit" name="register">Register</button>
            </form>
        </div>

        <!-- Login Form -->
        <div class="form-box">
            <form method="post">
                <h2>Login</h2>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>

                <button type="submit" name="login">Login</button>
            </form>
        </div>

    </div>

    <footer>
        <p>
            Owner: PS.FARM <br>
            Email: PS.FARM@student.green.edu.bd <br>
            Phone: 01403059772
        </p>
    </footer>
</body>
</html>
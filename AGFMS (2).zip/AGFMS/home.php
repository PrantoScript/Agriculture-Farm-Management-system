<?php
session_start();

// যদি login না থাকে → redirect
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// ✅ Correct DB Connection
$conn = new mysqli("localhost", "root", "", "agfms");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ================= USER INFO =================
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// ================= FARMER DATA =================
$orders = [];
$reviews = [];

if ($role === 'farmer') {

    // Orders (Prepared)
    $stmt = $conn->prepare("
        SELECT o.order_id, o.buyer_id, o.product_id, o.quantity, o.order_date, 
               o.delivery_address, o.phone_number, m.product_name 
        FROM orders o
        JOIN marketplace m ON o.product_id = m.product_id
        WHERE m.farmer_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $order_result = $stmt->get_result();

    while ($row = $order_result->fetch_assoc()) {
        $orders[] = $row;
    }

    // Reviews (Prepared)
    $stmt = $conn->prepare("
        SELECT r.rating, r.comment, r.review_date, m.product_name 
        FROM reviews r
        JOIN marketplace m ON r.product_id = m.product_id
        WHERE m.farmer_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $review_result = $stmt->get_result();

    while ($row = $review_result->fetch_assoc()) {
        $reviews[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - Agriculture Farm Management System</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        table th {
            background-color: #f4f4f4;
        }
        .section-header {
            margin: 20px 0 10px;
            font-size: 1.2em;
            font-weight: bold;
        }
    </style>
</head>
<body>

<header>
    <h1>Agriculture Farm Management System</h1>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>

            <?php if ($role === 'farmer') { ?>
                <li><a href="manage_farm.php">Manage Farm</a></li>
            <?php } ?>

            <li><a href="marketplace.php">Marketplace</a></li>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="main.php?logout=true">Log Out</a></li>
        </ul>
    </nav>
</header>

<main>

<h2>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>

<div class="user-details">
    <p><strong>Role: </strong> <?php echo ucfirst($user['role']); ?></p><br>
    <p><strong>Username: </strong> <?php echo htmlspecialchars($user['username']); ?></p>
</div>

<?php if ($role === 'farmer') { ?>

    <!-- Orders -->
    <section>
        <div class="section-header">Your Orders</div>

        <?php if (!empty($orders)) { ?>
            <table>
                <tr>
                    <th>Order ID</th>
                    <th>Buyer ID</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Date</th>
                    <th>Address</th>
                    <th>Phone</th>
                </tr>

                <?php foreach ($orders as $order) { ?>
                    <tr>
                        <td><?php echo $order['order_id']; ?></td>
                        <td><?php echo $order['buyer_id']; ?></td>
                        <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                        <td><?php echo $order['quantity']; ?></td>
                        <td><?php echo $order['order_date']; ?></td>
                        <td><?php echo htmlspecialchars($order['delivery_address']); ?></td>
                        <td><?php echo htmlspecialchars($order['phone_number']); ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <p>No orders found.</p>
        <?php } ?>
    </section>

    <!-- Reviews -->
    <section>
        <div class="section-header">Product Reviews</div>

        <?php if (!empty($reviews)) { ?>
            <table>
                <tr>
                    <th>Product</th>
                    <th>Rating</th>
                    <th>Comment</th>
                    <th>Date</th>
                </tr>

                <?php foreach ($reviews as $review) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($review['product_name']); ?></td>
                        <td><?php echo $review['rating']; ?>/5</td>
                        <td><?php echo htmlspecialchars($review['comment']); ?></td>
                        <td><?php echo $review['review_date']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <p>No reviews yet.</p>
        <?php } ?>
    </section>

<?php } ?>

</main>
</body>
</html>